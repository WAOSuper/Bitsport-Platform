<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use App\Models\Bet;
use App\Models\Cms;
use Stripe\Stripe;
use Stripe\Customer;
use Stripe\Charge;
use App\Models\Tournament;
use App\Models\Participant;
use App\Models\Setting;
use Sentinel;

class PaymentController extends Controller
{
    public function stripePayment(Request $request)
    {
       try {
            $user = Sentinel::getUser();
            $tournamentId = $request->input('_tournament_id');
            $tournament = Tournament::where('id', $tournamentId)->first();
            Stripe::setApiKey(env('STRIPE_SECRET_KEY'));

            $customer = Customer::create(
              [
                'email' => $request->stripeEmail,
                'source' => $request->stripeToken
              ]
            );

            $charge = Charge::create(
              [
                'customer' => $customer->id,
                'amount' => $tournament->fees * 10,
                'currency' => 'usd'
              ]
            );

            $participant = new Participant;
            $participant->user_id = $user->id;
            $participant->tournament_id = $tournamentId;
            $participant->payment_source = 'Stripe';
            $participant->currency = 'USD';
            $participant->amount = $tournament->fees;
            $participant->timezone = $_POST['timezone'];
            $participant->twitch_url = $_POST['twitch_url'];
            $participant->gamer_id = $_POST['gamer_id'];
            $participant->host_event = $_POST['host_event'];
            $participant->preffered_time = $_POST['preffered_time'];

            $participant->save();
            session(['success' => "You successfully joined the tournament"]);
            return redirect('tournament/'.$tournamentId)->with('success', 'You successfully joined the tournament');
        } catch (\Exception $ex) {
                    return redirect('tournament/'.$tournamentId)->with('error', 'Payment Unsuccessful');

        }
    }

    public function btpPayment(Request $request)
    {
       try {
            $user = Sentinel::getUser();
            $tournamentId = $request->input('_tournament_id');
            $tournament = Tournament::where('id', $tournamentId)->first();
            $setting =Setting::first();

            $btpValue= $tournament->fees;

            $btpValue = round($btpValue, 2);

            if ($user->mbtc < $btpValue) {
                return redirect()->action(
                'TournamentController@getTournament',
                  [$tournament]
              )->with('error', 'Insufficient Balance');
            }

            $user->mbtc = $user->mbtc - $btpValue;
            $user->save();
            $participant = new Participant;
            $participant->user_id = $user->id;
            $participant->tournament_id = $tournamentId;
            $participant->payment_source = 'BTP';
            $participant->currency = 'BTP';
            $participant->amount = $tournament->fees;
            $participant->timezone = isset($_POST['timezone']) ? $_POST['timezone'] : '';
            $participant->twitch_url = isset($_POST['twitch_url']) ? $_POST['twitch_url'] : '';
            $participant->gamer_id = isset($_POST['gamer_id']) ? $_POST['gamer_id'] : '';
            $participant->host_event = isset($_POST['host_event']) ? $_POST['host_event'] : '';
            $participant->preffered_time = isset($_POST['preffered_time']) ?  $_POST['preffered_time'] : '';
            $participant->save();

            return redirect()->action(
              'TournamentController@getTournament',
                [$tournament]
            )->with('success', 'You successfully joined the tournament');
        } catch (\Exception $ex) {
          return redirect()->action(
            'TournamentController@getTournament',
              [$tournament]
              )->with('error', 'Payment Unsuccessful');
        }
    }

    public function index($id) {
      $user = Sentinel::getuser();
      $tournament = Tournament::where('id', $id)->first();
      $balance = (Sentinel::check()) ? User::where('id', Sentinel::getUser()->id)->pluck('mbtc')->first() : 0;
      $bets = (Sentinel::check()) ? Bet::where('user_id', Sentinel::check()->id)->where('status', 0)->get() : 0;
      return view('frontend.tournament.payment', compact('user', 'tournament', 'balance', 'bets'));
    }
}
