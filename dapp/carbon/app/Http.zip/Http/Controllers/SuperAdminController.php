<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Bet;
use App\Models\Setting;
use App\Models\Coupon;
use App\Models\CouponRedeemed;
use App\User;

class SuperAdminController extends Controller
{
    public function dashboard()
    {
    	$date = strtotime("-7 day");
		$last = date('Y-m-d', $date);
        $today = date('Y-m-d');

    	$bet = Bet::where('status',1)->get();
    	$weekbet = Bet::whereBetween('date_time', array($last, $today))->where('win', 0)->get();
    	$user = User::where('status',0)->get();
		$weekuser = User::whereBetween('created_at', array($last, $today))->where('status', 0)->get();

        $user = array();
        $user =User::get();

        $created_at = date('Y-m-d H:i:s', strtotime($user[0]['created_at'] . " -168 hours"));    
        $new_user_list = User::whereNotIn('id', array(1, 2))->where('created_at', '>', $created_at)->get();        
        $week_users = count($new_user_list);

        $newlist = User::whereNotIn('id', array(1, 2))->get();
        $new_users =count($newlist);

        return view('superadmin.dashboard', compact('bet', 'weekbet', 'user', 'weekuser', 'week_users', 'new_users'));
    }

    public function setting()
    {
        $setting=Setting::find(1);
        return view('superadmin.setting', compact('setting'));
    }

    public function settingUpdate(Request $request)
    {
        $this->validate($request,[
            'rate' => 'required'
        ]);

        $setting = Setting::find(1);
        $setting->rate = $request->rate;
        $setting->per = $request->per;
        $setting->update();

        return redirect()->back()->with(['success' => "Successfully Rate Updated."]);

    }

    function generateCouponCode()
    {
        $coupon_code = substr(md5(uniqid(mt_rand(), true)), 0, 8);

        $coupon = Coupon::where('coupon',$coupon_code)->first();
        if(!$coupon)
        {
            return $coupon_code;
        }
        return $this->generateCouponCode();
    }

    public function rewards()
    {
        $coupon = $this->generateCouponCode();

        $coupons = Coupon::get();

        return view('superadmin.rewards',compact('coupon','coupons'));
    }

    public function addCoupon(Request $request)
    {
        $data = $request->all();
        $coupon = $data['coupon'];
        $amount = $data['amount'];
        $usage  = $data['usage'];

        Coupon::create(['coupon' => $coupon, 'amount' => $amount, 'usage_limit' => $usage]);

        return redirect()->back()->with(['success' => "Successfully Coupon Added."]);
    }

    public function redeemCoupon($coupon_code)
    {
        $coupon = Coupon::where('coupon',$coupon_code)->first();
        $user_list = CouponRedeemed::with('user')->where('coupon_id',$coupon['id'])->get();
        return view('superadmin.redeem-list',compact('coupon','user_list'));
    }
}
